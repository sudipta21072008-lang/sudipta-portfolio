TECH VESTER MATERIALS LAB V3 WORKING

This is V3 with the molecular mechanism controls restored to the exact
working JavaScript pattern used in V2.

The buttons are:
Break the interface
Re-form interactions

Open index.html in Chrome or Edge.
